#!/bin/sh

echo "DhyveOS version $(cat /etc/version)"
docker -v
